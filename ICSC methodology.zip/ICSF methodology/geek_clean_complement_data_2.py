import pandas as pd

real_data = pd.read_csv('geek_discretized_1_blur_filter_desktop_models.csv')

complemented_data = pd.read_csv('geek_discretized_valid_complement_1_blur_desktop.csv')


feature_ranges = {
    'Clock Speed Discretized': sorted(real_data['Clock Speed Discretized'].unique()),
    'L2 Discretized': sorted(real_data['L2 Discretized'].unique()),
    'L3 Discretized': sorted(real_data['L3 Discretized'].unique()),
    'Memory Discretized': sorted(real_data['Memory Discretized'].unique()),
    'Processing Capability Discretized': sorted(real_data['Processing Capability Discretized'].unique()),
    'Num. of Threads Discretized': sorted(real_data['Num. of Threads Discretized'].unique()),
}

def get_neighbors(point, feature_ranges, columns):
    neighbors = set()
    for i, col in enumerate(columns):
        for delta in [-1, 1]:
            neighbor = point.copy()
            neighbor[i] += delta
            if neighbor[i] in feature_ranges[col]:
                neighbors.add(tuple(neighbor))
    return neighbors


def remove_near_points(real_data, comp_data, feature_ranges):
    real_points = {tuple(row) for row in real_data.values}
    comp_points = {tuple(row) for row in comp_data.values}

    points_to_remove = set()
    for point in real_points:
        points_to_remove.update(get_neighbors(list(point), feature_ranges, real_data.columns))

    initial_count = len(comp_points)

    clean_comp_points = comp_points - points_to_remove

    final_count = len(clean_comp_points)

    removed_count = initial_count - final_count

    print(f"Number of real data points: {len(real_points)}")
    print(f"Number of complement data points before removing: {initial_count}")
    print(f"Number of complement data points after removing: {final_count}")
    print(f"Number of data points removed: {removed_count}")

    clean_complemented_data = pd.DataFrame(list(clean_comp_points), columns=real_data.columns)

    return clean_complemented_data



clean_complemented_data = remove_near_points(real_data, complemented_data, feature_ranges)

clean_complemented_data.to_csv('geek_discretized_clean_complement_1_blur_desktop.csv', index=False)

