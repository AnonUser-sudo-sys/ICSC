import numpy as np
import pandas as pd
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import pairwise_distances
import matplotlib.pyplot as plt
import seaborn as sns
import os

output_dir = 'BitBrains_iteration_centers'
os.makedirs(output_dir, exist_ok=True)

real_data_path = 'combined_BitBrains_data_with_coarse_granularity.csv'
real_data = pd.read_csv(real_data_path)
data = pd.read_csv('combined_BitBrains_data_with_coarse_granularity_valid_clean_complement.csv')

scaler = MinMaxScaler()
data_scaled = scaler.fit_transform(
    data[['CPU cores Discretized',
    'CPU capacity provisioned [MHZ] Discretized',
    'Memory capacity provisioned [KB] Discretized',
    'Network received throughput [KB/s] Discretized',
    'Network transmitted throughput [KB/s] Discretized',
    'Disk read throughput [KB/s] Discretized',
    'Disk write throughput [KB/s] Discretized']])


eps = 0.5
min_samples = 8

def remove_points_within_eps(data, centers_df, eps, scaler, iteration):
    data_array = scaler.transform(data.drop(columns=['cluster'], errors='ignore'))
    centers_array = scaler.transform(centers_df)
    distances = pairwise_distances(data_array, centers_array)
    points_within_eps = np.min(distances, axis=1) <= eps
    points_to_remove = np.any(distances <= eps, axis=1)
    num_points_within_eps = np.sum(points_within_eps)
    num_points_to_remove = np.sum(points_to_remove)

    print(f'Total points within epsilon {eps} in iteration {iteration}: {num_points_within_eps}')
    print(f'Points to remove in iteration {iteration}: {num_points_to_remove}')

    if num_points_to_remove > 0:
        print(f'Example distances in iteration {iteration}:\n{distances[:5, :5]}')
        print(f'Indices of points to remove in iteration {iteration}: {np.where(points_to_remove)[0][:10]}')
        print(f'Points being removed in iteration {iteration}:\n{data[points_to_remove].head(10)}')

    distances_within_eps_df = pd.DataFrame({
        'point_index': np.where(points_within_eps)[0],
        'distance_to_nearest_center': np.min(distances, axis=1)[points_within_eps]
    })
    distances_within_eps_df['iteration'] = iteration

    plt.figure(figsize=(10, 6))
    sns.histplot(distances.flatten(), bins=50, kde=True)
    plt.axvline(x=eps, color='r', linestyle='--')
    plt.title('Distribution of Distances')
    plt.xlabel('Distance')
    plt.ylabel('Frequency')
    #plt.show()
    clean_data = data[~points_to_remove]

    return clean_data, num_points_within_eps, num_points_to_remove, distances_within_eps_df
def find_closest_in_cluster(cluster_data, center):
    distances = pairwise_distances(cluster_data, center.reshape(1, -1))
    return cluster_data.iloc[np.argmin(distances)]

colors = ['red', 'blue', 'green', 'purple', 'orange', 'brown', 'pink', 'gray', 'olive', 'cyan']

all_centers = []
iteration = 0
pairwise_distances_all_iterations = pd.DataFrame()

while True:
    X = data[['CPU cores Discretized',
    'CPU capacity provisioned [MHZ] Discretized',
    'Memory capacity provisioned [KB] Discretized',
    'Network received throughput [KB/s] Discretized',
    'Network transmitted throughput [KB/s] Discretized',
    'Disk read throughput [KB/s] Discretized',
    'Disk write throughput [KB/s] Discretized']]

    X_scaled = scaler.fit_transform(X)
    dbscan = DBSCAN(eps=eps, min_samples=min_samples)
    clusters = dbscan.fit_predict(X_scaled)

    data['cluster'] = clusters

    holes = data[data['cluster'] != -1]

    num_clusters = len(holes['cluster'].unique())
    print(f'Iteration {iteration}: Number of clusters = {num_clusters}')

    cluster_counts = holes['cluster'].value_counts()
    print(f'Iteration {iteration}: Points in each cluster:\n{cluster_counts}')

    if num_clusters == 0:
        break
    new_centers = []
    for cluster in holes['cluster'].unique():
        cluster_data = holes[holes['cluster'] == cluster].drop(columns=['cluster'])
        cluster_center = cluster_data.mean().values
        closest_point = find_closest_in_cluster(cluster_data, cluster_center)
        new_centers.append(closest_point.values)
    all_centers.extend(new_centers)
    cumulative_centers = len(all_centers)
    print(f'Iteration {iteration}: Cumulative number of center clusters = {cumulative_centers}')
    new_centers_df = pd.DataFrame(new_centers, columns=data.columns[:-1])
    print(f'Iteration {iteration}: New centers:\n{new_centers_df}')

    centers_df = pd.DataFrame(new_centers, columns=data.columns[:-1])
    all_centers_df = pd.DataFrame(all_centers, columns=data.columns[:-1])

    print(f'Before removal: {data.shape[0]} points')
    print(f'Data points (sample) before removal: {data.sample(5).values.tolist()}')
    data, num_points_within_eps, num_points_to_remove, distances_within_eps_df = remove_points_within_eps(data, centers_df, eps, scaler, iteration)
    print(f'After removal: {data.shape[0]} points')
    if data.shape[0] > 0:
        print(f'Data points (sample) after removal: {data.sample(5).values.tolist()}')
    else:
        print('No data points remaining after removal.')

    print(f'Iteration {iteration}: Total points within epsilon {eps} = {num_points_within_eps}')
    print(f'Iteration {iteration}: Points removed = {num_points_to_remove}')

    pairwise_distances_all_iterations = pd.concat([pairwise_distances_all_iterations, distances_within_eps_df], ignore_index=True)

    if data.shape[0] == 0:
        break

    data = data.reset_index(drop=True)

    X_scaled = scaler.fit_transform(
        data[['CPU cores Discretized',
    'CPU capacity provisioned [MHZ] Discretized',
    'Memory capacity provisioned [KB] Discretized',
    'Network received throughput [KB/s] Discretized',
    'Network transmitted throughput [KB/s] Discretized',
    'Disk read throughput [KB/s] Discretized',
    'Disk write throughput [KB/s] Discretized']])

    combined_data = pd.concat([real_data, all_centers_df])
    combined_data['source'] = ['Real Data'] * len(real_data) + [f'Iteration {iteration}'] * len(all_centers_df)

    palette = {f'Iteration {i}': colors[i % len(colors)] for i in range(iteration + 1)}
    palette['Real Data'] = 'black'
    sns.pairplot(combined_data, hue='source', diag_kind='kde', markers=['o', 's'], palette=palette,
                 plot_kws={'alpha': 0.5})
    plt.suptitle(f'Pair Plot of Real Data and Iteration {iteration} Centers', y=1.02)
    #plt.show()

    iteration += 1

final_centers_df = pd.DataFrame(all_centers, columns=data.columns[:-1])
final_centers_df.to_csv('BitBrains_final_optimized_data_points.csv', index=False)

pairwise_distances_all_iterations.to_csv('pairwise_distances_within_eps_all_iterations.csv', index=False)

real_data['source'] = 'Real Data'
final_centers_df['source'] = 'Optimized Points'
combined_data = pd.concat([real_data, final_centers_df])

sns.pairplot(combined_data, hue='source', diag_kind='kde', markers=['o', 's'])
plt.suptitle('Pair Plot of Real Data and Final Optimized Points', y=1.02)
plt.show()
