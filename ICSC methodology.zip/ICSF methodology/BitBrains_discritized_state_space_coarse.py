import pandas as pd
import numpy as np

file_path = 'combined_BitBrains_data_with_log.csv'
data = pd.read_csv(file_path)

def discretize_by_base_unit(value, base, offset=0):
    return base * np.floor(value / base) + offset

data['CPU cores Discretized'] = data['CPU cores'].apply(lambda x: discretize_by_base_unit(x, 8, 8))
data['CPU capacity provisioned [MHZ] Discretized'] = data['CPU capacity provisioned [MHZ]'].apply(lambda x: discretize_by_base_unit(x, 2, 2))
data['Memory capacity provisioned [KB] Discretized'] = data['Memory capacity provisioned [KB]'].apply(lambda x: discretize_by_base_unit(x, 8, 8))
data['Network received throughput [KB/s] Discretized'] = data['Network received throughput [KB/s]'].apply(lambda x: discretize_by_base_unit(x, 4, 4))
data['Network transmitted throughput [KB/s] Discretized'] = data['Network transmitted throughput [KB/s]'].apply(lambda x: discretize_by_base_unit(x, 4, 4))
data['Disk read throughput [KB/s] Discretized'] = data['Disk read throughput [KB/s]'].apply(lambda x: discretize_by_base_unit(x, 4, 4))
data['Disk write throughput [KB/s] Discretized'] = data['Disk write throughput [KB/s]'].apply(lambda x: discretize_by_base_unit(x, 4, 4))
data['CPU usage [%] Discretized'] = data['CPU usage [%]'].apply(lambda x: discretize_by_base_unit(x, 40, 40))

columns_to_drop = [
    'CPU cores', 'CPU capacity provisioned [MHZ]', 'Memory capacity provisioned [KB]',
    'Network received throughput [KB/s]', 'Network transmitted throughput [KB/s]',
    'Disk read throughput [KB/s]', 'Disk write throughput [KB/s]', 'CPU usage [%]'
]
data.drop(columns=columns_to_drop, axis=1, inplace=True)

data.drop_duplicates(inplace=True)
data.dropna(inplace=True)

output_file_path = 'combined_BitBrains_data_with_coarse_granularity.csv'
data.to_csv(output_file_path, index=False)
