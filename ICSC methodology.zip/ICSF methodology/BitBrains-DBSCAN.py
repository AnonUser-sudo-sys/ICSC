import pandas as pd
import numpy as np
from sklearn.neighbors import NearestNeighbors
import matplotlib.pyplot as plt
from kneed import KneeLocator
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import silhouette_score

data = pd.read_csv('combined_BitBrains_data_with_coarse_granularity_valid_clean_complement.csv')



X = data[['CPU cores Discretized', 'CPU capacity provisioned [MHZ] Discretized',
    'Memory capacity provisioned [KB] Discretized', 'Network received throughput [KB/s] Discretized',
    'Network transmitted throughput [KB/s] Discretized', 'Disk read throughput [KB/s] Discretized',
    'Disk write throughput [KB/s] Discretized']]

scaler = MinMaxScaler()
X_scaled = scaler.fit_transform(X)

manual_eps = None  # Set to None if you want to perform grid search
manual_min_samples = None  # Set to None if you want to perform grid search

eps_values = np.arange(0.1, 2, 0.1)
min_samples_values = range(2, 10)

best_silhouette = -1
best_eps = None
best_min_samples = None
best_clusters = None

if manual_eps is not None and manual_min_samples is not None:
    dbscan = DBSCAN(eps=manual_eps, min_samples=manual_min_samples)
    clusters = dbscan.fit_predict(X_scaled)
    if len(set(clusters)) > 1:  # More than one cluster is formed
        silhouette_avg = silhouette_score(X_scaled, clusters)
        print(f'Eps: {manual_eps}, Min Samples: {manual_min_samples}, Silhouette Score: {silhouette_avg}')
        best_silhouette = silhouette_avg
        best_eps = manual_eps
        best_min_samples = manual_min_samples
        best_clusters = clusters
else:
    for eps in eps_values:
        for min_samples in min_samples_values:
            dbscan = DBSCAN(eps=eps, min_samples=min_samples)
            clusters = dbscan.fit_predict(X_scaled)
            print("eps: ", eps, "min_samples: ", min_samples, "num. of clusters: ",  len(set(clusters)))
            if len(set(clusters)) > 1:  # More than one cluster is formed
                silhouette_avg = silhouette_score(X_scaled, clusters)
                print(f'Eps: {eps}, Min Samples: {min_samples}, Silhouette Score: {silhouette_avg}')
                if silhouette_avg > best_silhouette:
                    best_silhouette = silhouette_avg
                    best_eps = eps
                    best_min_samples = min_samples
                    best_clusters = clusters

    print(f'Best eps value: {best_eps}')
    print(f'Best min_samples value: {best_min_samples}')
    print(f'Best silhouette score: {best_silhouette}')

dbscan = DBSCAN(eps=best_eps, min_samples=best_min_samples)
clusters = dbscan.fit_predict(X_scaled)

data['cluster'] = clusters

holes = data[data['cluster'] != -1]

holes.to_csv('BitBrains_complemented_data_with_clusters.csv', index=False)
features = holes.columns[:-1]

import pandas as pd
import numpy as np
from sklearn.metrics import pairwise_distances
import seaborn as sns

data_path = 'BitBrains_complemented_data_with_clusters.csv'
data = pd.read_csv(data_path)

features = ['CPU cores Discretized', 'CPU capacity provisioned [MHZ] Discretized',
    'Memory capacity provisioned [KB] Discretized', 'Network received throughput [KB/s] Discretized',
    'Network transmitted throughput [KB/s] Discretized', 'Disk read throughput [KB/s] Discretized',
    'Disk write throughput [KB/s] Discretized']

clusters = data['cluster'].unique()
cluster_centers = []
cluster_diameters = []
closest_points = []

def find_closest_in_cluster(cluster, point):
    distances = pairwise_distances(cluster, point.reshape(1, -1))
    return cluster.iloc[np.argmin(distances)]

for cluster in clusters:
    cluster_data = data[data['cluster'] == cluster].drop(columns=['cluster'])
    center = cluster_data.mean().values
    distances = np.linalg.norm(cluster_data.values - center, axis=1)
    diameter = distances.max() * 2
    closest_point = find_closest_in_cluster(cluster_data, center)

    cluster_centers.append(center)
    cluster_diameters.append(diameter)
    closest_points.append(closest_point)

selected_points_df = pd.DataFrame(closest_points)
selected_points_df['Diameter'] = cluster_diameters
selected_points_df['Cluster'] = clusters
selected_points_df.to_csv('BitBrains_selected_optimized_data_points.csv', index=False)


real_data_path = 'combined_BitBrains_data_with_coarse_granularity.csv'
real_data = pd.read_csv(real_data_path)

real_data['source'] = 'Real Data'
columns_to_drop = ["Diameter", "Cluster"]
selected_points_df.drop(columns=columns_to_drop, axis=1, inplace=True)

selected_points_df['source'] = 'Optimized Points'

combined_data = pd.concat([real_data, selected_points_df])

sns.pairplot(combined_data, hue='source', diag_kind='kde', markers=['o', 's'])
plt.suptitle('Pair Plot of Real Data and Selected Optimized Points', y=1.02)
plt.show()
