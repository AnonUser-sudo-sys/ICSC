import numpy as np
import pandas as pd
from itertools import product

file_path = 'combined_BitBrains_data_with_coarse_granularity.csv'
real_data = pd.read_csv(file_path)

feature_ranges = {
    'CPU cores Discretized': sorted(real_data['CPU cores Discretized'].unique()),
    'CPU capacity provisioned [MHZ] Discretized': sorted(real_data['CPU capacity provisioned [MHZ] Discretized'].unique()),
    'Memory capacity provisioned [KB] Discretized': sorted(real_data['Memory capacity provisioned [KB] Discretized'].unique()),
    'Network received throughput [KB/s] Discretized': sorted(real_data['Network received throughput [KB/s] Discretized'].unique()),
    'Network transmitted throughput [KB/s] Discretized': sorted(real_data['Network transmitted throughput [KB/s] Discretized'].unique()),
    'Disk read throughput [KB/s] Discretized': sorted(real_data['Disk read throughput [KB/s] Discretized'].unique()),
    'Disk write throughput [KB/s] Discretized': sorted(real_data['Disk write throughput [KB/s] Discretized'].unique())
}

all_combinations = list(product(
    feature_ranges['CPU cores Discretized'],
    feature_ranges['CPU capacity provisioned [MHZ] Discretized'],
    feature_ranges['Memory capacity provisioned [KB] Discretized'],
    feature_ranges['Network received throughput [KB/s] Discretized'],
    feature_ranges['Network transmitted throughput [KB/s] Discretized'],
    feature_ranges['Disk read throughput [KB/s] Discretized'],
    feature_ranges['Disk write throughput [KB/s] Discretized']
))

all_combinations_df = pd.DataFrame(all_combinations, columns=[
    'CPU cores Discretized',
    'CPU capacity provisioned [MHZ] Discretized',
    'Memory capacity provisioned [KB] Discretized',
    'Network received throughput [KB/s] Discretized',
    'Network transmitted throughput [KB/s] Discretized',
    'Disk read throughput [KB/s] Discretized',
    'Disk write throughput [KB/s] Discretized'
])

if 'CPU usage [%] Discretized' in real_data.columns:
    real_data = real_data.drop(columns=['CPU usage [%] Discretized'])
all_complement_data = pd.concat([all_combinations_df, real_data, real_data]).drop_duplicates(keep=False)

invalid_complement_data = all_complement_data[
    ((all_complement_data['Network received throughput [KB/s] Discretized'] >= 8.0) & (all_complement_data['Disk read throughput [KB/s] Discretized'] <= 4.0))
    |
    ((all_complement_data['CPU cores Discretized'] >= 8.0) & (all_complement_data['Network transmitted throughput [KB/s] Discretized'] <= 4.0))
    |
    ((all_complement_data['CPU capacity provisioned [MHZ] Discretized'] >= 10.0) & (all_complement_data['Disk write throughput [KB/s] Discretized'] <= 4.0))
]

all_complement_data['Validation'] = np.where(all_complement_data.index.isin(invalid_complement_data.index), 'invalid', 'valid')

valid_count = all_complement_data[all_complement_data['Validation'] == 'valid'].shape[0]
invalid_count = all_complement_data[all_complement_data['Validation'] == 'invalid'].shape[0]
print(f"Number of valid rows: {valid_count}")
print(f"Number of invalid rows: {invalid_count}")

all_complement_data.to_csv('combined_BitBrains_data_with_coarse_granularity_complement.csv', index=False)

valid_data = all_complement_data[all_complement_data['Validation'] == 'valid']
valid_data = valid_data.drop(columns=['Validation'])

valid_data.to_csv('combined_BitBrains_data_with_coarse_granularity_valid_complement.csv', index=False)

