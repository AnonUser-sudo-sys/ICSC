import pandas as pd
import json

input_json_path = 'geek_data_1.json'
df = pd.read_json(input_json_path)

aes_column_index = 5

workloads = ['AES', 'SHA2', 'Blur Filter', 'BZip2 Compress', 'Ray Trace', 'JPEG Compress']

for workload in workloads:
    workload_df = df[df.iloc[:, aes_column_index] == workload]

    workload_df = workload_df.drop(aes_column_index, axis=1)
    previous_version_data = [list(row) for row in workload_df.values]

    output_json_path_previous = f'geek_data_1_{workload.replace(" ", "_").lower()}.json'
    with open(output_json_path_previous, 'w') as f:
        json.dump(previous_version_data, f)

    print(f"{workload} data has been saved to {output_json_path_previous}")