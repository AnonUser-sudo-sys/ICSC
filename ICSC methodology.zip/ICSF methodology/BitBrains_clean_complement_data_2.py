import pandas as pd

real_data = pd.read_csv('combined_BitBrains_data_with_coarse_granularity.csv')

complemented_data = pd.read_csv('combined_BitBrains_data_with_coarse_granularity_valid_complement.csv')

feature_ranges = {
    'CPU cores Discretized': sorted(complemented_data['CPU cores Discretized'].unique()),
    'CPU capacity provisioned [MHZ] Discretized': sorted(complemented_data['CPU capacity provisioned [MHZ] Discretized'].unique()),
    'Memory capacity provisioned [KB] Discretized': sorted(complemented_data['Memory capacity provisioned [KB] Discretized'].unique()),
    'Network received throughput [KB/s] Discretized': sorted(complemented_data['Network received throughput [KB/s] Discretized'].unique()),
    'Network transmitted throughput [KB/s] Discretized': sorted(complemented_data['Network transmitted throughput [KB/s] Discretized'].unique()),
    'Disk read throughput [KB/s] Discretized': sorted(complemented_data['Disk read throughput [KB/s] Discretized'].unique()),
    'Disk write throughput [KB/s] Discretized': sorted(complemented_data['Disk write throughput [KB/s] Discretized'].unique()),
  
}
def get_neighbors(point, feature_ranges, columns):
    neighbors = set()
    for i, col in enumerate(columns):
        if col not in feature_ranges:
            continue
        for delta in [-1, 1]:
            neighbor = point.copy()
            neighbor[i] += delta
            if neighbor[i] in feature_ranges[col]:
                neighbors.add(tuple(neighbor))
    return neighbors

def remove_near_points(real_data, comp_data, feature_ranges):
    real_points = {tuple(row) for row in real_data.values}
    comp_points = {tuple(row) for row in comp_data.values}
    points_to_remove = set()
    for point in real_points:
        points_to_remove.update(get_neighbors(list(point), feature_ranges, real_data.columns))
    initial_count = len(comp_points)
    clean_comp_points = comp_points - points_to_remove
    final_count = len(clean_comp_points)
    removed_count = initial_count - final_count
    print(f"Number of real data points: {len(real_points)}")
    print(f"Number of complement data points before removing: {initial_count}")
    print(f"Number of complement data points after removing: {final_count}")
    print(f"Number of data points removed: {removed_count}")
    clean_complemented_data = pd.DataFrame(list(clean_comp_points), columns=comp_data.columns)
    return clean_complemented_data

clean_complemented_data = remove_near_points(real_data, complemented_data, feature_ranges)

output_path = 'combined_BitBrains_data_with_coarse_granularity_valid_clean_complement.csv'
clean_complemented_data.to_csv(output_path, index=False)