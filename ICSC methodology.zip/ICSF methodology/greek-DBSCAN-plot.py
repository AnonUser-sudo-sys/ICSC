import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import itertools

data_path = 'complemented_data_with_clusters.csv'
real_data_path = 'geek_discretized_1_blur_filter_desktop_models.csv'

data = pd.read_csv(data_path)
real_data = pd.read_csv(real_data_path)

data['cluster'] = 'Cluster ' + data['cluster'].astype(str)
real_data['cluster'] = 'Real Data'

dimensions = [
    'Clock Speed Discretized',
    'L2 Discretized',
    'L3 Discretized',
    'Memory Discretized',
    'Processing Capability Discretized',
    'Num. of Threads Discretized',
    'Throughput Discretized'
]

data_reset = data.reset_index(drop=True)
real_data_combined_reset = real_data.reset_index(drop=True)

visualization_data_reset = pd.concat([data_reset, real_data_combined_reset], ignore_index=True)

cluster_colors = sns.color_palette('viridis', len(data_reset['cluster'].unique()))
cluster_color_map = {f'Cluster {i}': cluster_colors[i] for i in range(len(cluster_colors))}
real_data_color = 'red'

fig, axes = plt.subplots(nrows=len(dimensions), ncols=len(dimensions), figsize=(20, 20))
fig.suptitle('Scatter Plot Matrix of Clusters and Real Data across All Dimensions', y=1.02)

for i, j in itertools.product(range(len(dimensions)), range(len(dimensions))):
    if i == j:
        axes[i, j].hist(data_reset[dimensions[i]], bins=20, color='grey', alpha=0.7, label='Cluster Data')
        axes[i, j].hist(real_data_combined_reset[dimensions[i]], bins=20, color=real_data_color, alpha=0.7,
                        label='Real Data')
        axes[i, j].set_ylabel(dimensions[i])
        axes[i, j].set_xlabel(dimensions[j])
    else:
        for cluster, color in cluster_color_map.items():
            cluster_data = data_reset[data_reset['cluster'] == cluster]
            axes[i, j].scatter(cluster_data[dimensions[j]], cluster_data[dimensions[i]], c=[color], s=1, alpha=0.5,
                               label=cluster)
        axes[i, j].scatter(real_data_combined_reset[dimensions[j]], real_data_combined_reset[dimensions[i]],
                           c=real_data_color, edgecolor='black', s=10, label='Real Data')

    if i == len(dimensions) - 1:
        axes[i, j].set_xlabel(dimensions[j])
    if j == 0:
        axes[i, j].set_ylabel(dimensions[i])

handles, labels = [], []
for cluster, color in cluster_color_map.items():
    handles.append(plt.Line2D([0], [0], marker='o', color='w', markerfacecolor=color, markersize=10))
    labels.append(cluster)
handles.append(plt.Line2D([0], [0], marker='o', color='w', markerfacecolor=real_data_color, markersize=10,
                          markeredgecolor='black'))
labels.append('Real Data')
fig.legend(handles, labels, loc='upper right')

plt.tight_layout()
plt.show()


