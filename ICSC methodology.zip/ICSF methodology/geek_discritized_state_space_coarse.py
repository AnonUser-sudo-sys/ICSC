import pandas as pd
import numpy as np


data = pd.read_csv('geek_data_1_blur_filter_desktop_models.csv')

def discretize_by_base_unit(value, base, offset=0):
    return base * np.floor(value / base) + offset


data['Clock Speed Discretized'] = data['Clock Speed'].apply(lambda x: discretize_by_base_unit(x, 1, 1)) 
l2_mapping = {value: idx + 1 for idx, value in enumerate(sorted(data['L2'].unique()))}
data['L2 Discretized'] = data['L2'].map(l2_mapping)
data['L3 Discretized'] = data['L3'].apply(lambda x: discretize_by_base_unit(x, 1, 1))  
data['Memory Discretized'] = data['Memory'].apply(lambda x: discretize_by_base_unit(x, 1, 1))  
data['Processing Capability Discretized'] = data['Theoretical Processing Capability'].apply(lambda x: discretize_by_base_unit(x, 10, 10))  
data['Num. of Threads Discretized'] = data['Adjusted Num. of Threads'].apply(lambda x: discretize_by_base_unit(x, 4, 4))  
data['Throughput Discretized'] = data['Throughput'].apply(lambda x: discretize_by_base_unit(x, 8, 8))  

columns_to_drop = ["Clock Speed", "L2", "L3", "Memory", "Throughput", "Adjusted Num. of Threads", "Theoretical Processing Capability"]
data.drop(columns=columns_to_drop, axis=1, inplace=True)

data.drop_duplicates(inplace=True)
data.dropna(inplace=True)

feature_ranges = {
    'Clock Speed Discretized': sorted(data['Clock Speed Discretized'].unique()),
    'L2 Discretized': sorted(data['L2 Discretized'].unique()),
    'L3 Discretized': sorted(data['L3 Discretized'].unique()),
    'Memory Discretized': sorted(data['Memory Discretized'].unique()),
    'Processing Capability Discretized': sorted(data['Processing Capability Discretized'].unique()),
    'Num. of Threads Discretized': sorted(data['Num. of Threads Discretized'].unique()),
    'Throughput Discretized': sorted(data['Throughput Discretized'].unique())
}
for feature, values in feature_ranges.items():
    print(f"{feature}: {values}")

real_points = {tuple(row) for row in data.values}
print(f"Number of real data points: {len(real_points)}")

data.to_csv('geek_discretized_1_blur_filter_desktop_models.csv', index=False)

data_without_throughput = data.drop(columns=['Throughput Discretized'])

data_without_throughput.to_csv('geek_discretized_1_blur_filter_desktop_models_without_throughput.csv', index=False)
