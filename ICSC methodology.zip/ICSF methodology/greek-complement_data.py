import numpy as np
import pandas as pd
from itertools import product

real_data = pd.read_csv('geek_discretized_1_blur_filter_desktop_models.csv')

X = real_data[['Clock Speed Discretized', 'L2 Discretized', 'L3 Discretized', 'Memory Discretized',
               'Processing Capability Discretized', 'Num. of Threads Discretized']]#, 'Throughput Discretized']]


feature_ranges = {
    'Clock Speed Discretized': sorted(real_data['Clock Speed Discretized'].unique()),
    'L2 Discretized': sorted(real_data['L2 Discretized'].unique()),
    'L3 Discretized': sorted(real_data['L3 Discretized'].unique()),
    'Memory Discretized': sorted(real_data['Memory Discretized'].unique()),
    'Processing Capability Discretized': sorted(real_data['Processing Capability Discretized'].unique()),
    'Num. of Threads Discretized': sorted(real_data['Num. of Threads Discretized'].unique()),
}

print("Feature ranges of real data: ")
for feature, values in feature_ranges.items():
    print(f"{feature}: {values}")

all_combinations = list(product(
    feature_ranges['Clock Speed Discretized'],
    feature_ranges['L2 Discretized'],
    feature_ranges['L3 Discretized'],
    feature_ranges['Memory Discretized'],
    feature_ranges['Processing Capability Discretized'],
    feature_ranges['Num. of Threads Discretized'],
))



all_combinations_df = pd.DataFrame(all_combinations, columns=real_data.columns)


all_complement_data = pd.concat([all_combinations_df, real_data, real_data]).drop_duplicates(keep=False)
invalid_complement_data = all_complement_data[
    ((all_complement_data['Clock Speed Discretized'] < 3.0) & (all_complement_data['L2 Discretized'] > 4)) |
    ((all_complement_data['Clock Speed Discretized'] > 4.0) & (all_complement_data['L2 Discretized'] < 2)) |
    ((all_complement_data['Clock Speed Discretized'] > 4.0) & (all_complement_data['Memory Discretized'] < 12.0)) |
    ((all_complement_data['Memory Discretized'] > 13.0) & (all_complement_data['Clock Speed Discretized'] < 3.0)) |
    ((all_complement_data['Memory Discretized'] < 10.0) & (all_complement_data['Num. of Threads Discretized'] > 8.0)) |
    ((all_complement_data['Memory Discretized'] > 12.0) & (all_complement_data['Num. of Threads Discretized'] < 12.0)) |
    ((all_complement_data['Processing Capability Discretized'] <= 10.0) & (all_complement_data['Memory Discretized'] < 10.0))
]

all_complement_data['Validation'] = np.where(all_complement_data.index.isin(invalid_complement_data.index), 'invalid', 'valid')

valid_count = all_complement_data[all_complement_data['Validation'] == 'valid'].shape[0]
invalid_count = all_complement_data[all_complement_data['Validation'] == 'invalid'].shape[0]
print(f"Number of valid rows: {valid_count}")
print(f"Number of invalid rows: {invalid_count}")

all_complement_data.to_csv('geek_discretized_complement_1_blur_desktop.csv', index=False)


valid_data = all_complement_data[all_complement_data['Validation'] == 'valid']

data = valid_data.drop(columns=['Validation'])

feature_ranges_complement_data = {
    'Clock Speed Discretized': sorted(data['Clock Speed Discretized'].unique()),
    'L2 Discretized': sorted(data['L2 Discretized'].unique()),
    'L3 Discretized': sorted(data['L3 Discretized'].unique()),
    'Memory Discretized': sorted(data['Memory Discretized'].unique()),
    'Processing Capability Discretized': sorted(data['Processing Capability Discretized'].unique()),
    'Num. of Threads Discretized': sorted(data['Num. of Threads Discretized'].unique()),
}

print("Feature ranges of complement data: ")
for feature, values in feature_ranges_complement_data.items():
    print(f"{feature}: {values}")

data.to_csv('geek_discretized_valid_complement_1_blur_desktop.csv', index=False)