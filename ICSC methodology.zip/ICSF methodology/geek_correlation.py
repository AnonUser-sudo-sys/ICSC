import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler

csv_files = [
    #'geek_discretized_1_blur_filter_desktop_models.csv',
    'geek_discretized_clean_complement_1_blur_desktop.csv',
    #'geek_data_1_blur_filter_desktop_models.csv'

    # server model and multicore
    #'geek_data_1_aes_server_models.csv',
    #'geek_data_1_sha2_server_models.csv',
    #'geek_data_1_blur_filter_server_models.csv',
    #'geek_data_1_bzip2_compress_server_models.csv',
    #'geek_data_1_ray_trace_server_models.csv',
    #'geek_data_1_jpeg_compress_server_models.csv',

    # desktop model and multicore
    #'geek_data_1_aes_desktop_models.csv',
    #'geek_data_1_sha2_desktop_models.csv',
    #'geek_data_1_blur_filter_desktop_models.csv',
    #'geek_data_1_bzip2_compress_desktop_models.csv',
    #'geek_data_1_ray_trace_desktop_models.csv',
    #'geek_data_1_jpeg_compress_desktop_models.csv'
]


def create_heatmap(df, filename):
    scaler = StandardScaler()
    df_scaled = scaler.fit_transform(df)

    df_standardized = pd.DataFrame(df_scaled, columns=df.columns)

    correlation_matrix = df_standardized.corr(method='pearson')
    correlation_matrix = correlation_matrix.fillna(0)

    plt.figure(figsize=(15, 14))
    sns.heatmap(correlation_matrix, annot=True, cmap="coolwarm", fmt=".2f", linewidths=.5)
    plt.title(f"Correlation Matrix Heatmap for {filename}")
    plt.savefig(f"{filename}_correlation_matrix_heatmap.png")
    plt.close()
    return correlation_matrix



excel_writer = pd.ExcelWriter('correlation_matrices.xlsx', engine='xlsxwriter')

for csv_file in csv_files:
    df = pd.read_csv(csv_file)
    sheet_name = csv_file[:31] if len(csv_file) > 31 else csv_file

    correlation_matrix = create_heatmap(df, csv_file)

    correlation_matrix.to_excel(excel_writer, sheet_name=sheet_name)

excel_writer.close()

