import pandas as pd
import json
import re
import numpy as np

def extract_threads(cache_str):
    if cache_str is None or pd.isna(cache_str):
        return None
    if not isinstance(cache_str, str):
        cache_str = str(cache_str)
    match = re.search(r'KB\s*x\s*(\d+)', cache_str)
    if match:
        return int(match.group(1))

    return None

model_threads = {
    'Intel Xeon X5690': 12,
    'Intel Core i5-4670K': 4,
    'Intel Xeon E5-2630 v2': 12,
    'Intel Xeon E5-2690 v3': 24,
    'Intel Xeon E5-2620 v3': 12,
    'Intel Xeon E5-2665': 16,
    'Intel Core i7-4790K': 8,
    'Intel Xeon E5-2676 v3': 24,
    'Intel Xeon E5-2660 v2': 20,
    'Intel Core i7-37700K': 8,
    'Intel Xeon E5-2687W v3': 20,
    'Intel Core 2 Duo T7700': 2,
    'Intel Xeon E5-2687W v2': 16,
    'Intel Xeon E5-2696 v2': 24,
    'Intel Core i7-3770K': 8,
    'Intel Core 2 Duo E6300': 2,
    'Intel Xeon E5-2697 v3': 28,
    'Intel Pentium G4400': 2,
    'Intel Xeon E5-2690 v2': 20,
    'Intel Xeon E5-2680 v3': 24,
    'Intel Core i7-5960X': 16,
    'Intel Core i5-6600K': 4,
    'Intel Xeon E5-2670 v2': 20,
    'Intel Xeon E5-2630 v3': 16,
    'Intel Xeon E312xx (Sandy Bridge)': 4,
    'Intel Xeon E5-2643 v3': 12,
    'Intel Xeon E7-4890 v2': 30,
    'Intel Core i7-4770K': 8,
    'Intel Xeon E5-2670 v3': 24,
    'Intel Pentium G3258': 2,
    'Intel Xeon E5-2680 v2': 20,
    'Intel Xeon E5-2650 v3': 20,
    'Intel Xeon E5-2650 v2': 16,
    'Intel Xeon E7-8867 v3': 36,
    'Intel Core i5-4690K': 4,
    'Intel Core i7-6700K': 8,
    'Intel Xeon E5-2683 v3': 28,
    'Intel Core i7-5820K': 12,
    'Intel Core i7-3960X': 12,
    'Intel Xeon E5-2697 v2': 24,
    'Qualcomm Qualcomm': 4,
    'QEMU Virtual version ( 64-rhel6)': 2,
    'Intel Core (Haswell)': 4
}

def calculate_total_cache(cache_str):
    match = re.match(r'(\d+)\s*KB', cache_str)
    if match:
        base_cache = int(match.group(1))
        return base_cache
    return None


def is_server_model(model):
    server_keywords = ['Xeon', 'Opteron', 'QEMU Virtual']
    return any(keyword in model for keyword in server_keywords)

def is_desktop_model(model):
    desktop_keywords = ['Core i', 'Pentium', 'Core 2', 'AMD']
    return any(keyword in model for keyword in desktop_keywords)


input_json_paths2 = ['geek_data_1_aes.json', 'geek_data_1_sha2.json', 'geek_data_1_blur_filter.json', 'geek_data_1_bzip2_compress.json',
                    'geek_data_1_ray_trace.json', 'geek_data_1_jpeg_compress.json']
input_json_paths = ['geek_data_1_blur_filter.json']

input_json_paths1 = ['geek_data_0_aes.json', 'geek_data_0_sha2.json', 'geek_data_0_blur_filter.json', 'geek_data_0_bzip2_compress.json', 'geek_data_0_ray_trace.json', 'geek_data_0_jpeg_compress.json',
'geek_data_1_aes.json', 'geek_data_1_sha2.json', 'geek_data_1_blur_filter.json', 'geek_data_1_bzip2_compress.json', 'geek_data_1_ray_trace.json', 'geek_data_1_jpeg_compress.json']



for input_json_path in input_json_paths:
    with open(input_json_path, 'r') as f:
        data = json.load(f)

    columns = ["Model", "Clock Speed", "L2", "L3", "Memory", "Performance Score", "Throughput"]
    df = pd.DataFrame(data, columns=columns)
    df = df.drop_duplicates()

    df = df[(df['Clock Speed'] >= 1) & (df['Clock Speed'] <= 3.5)]

    df["Num. of Threads"] = df['L2'].apply(extract_threads)
    hyper_threaded_models = ['Intel Xeon', 'Intel Core i7']
    df['Supports Hyper-threading'] = df['Model'].apply(lambda model: any(x in model for x in hyper_threaded_models))
    df['Adjusted Num. of Threads'] = df.apply(lambda row: row['Num. of Threads'] * 2 if row['Supports Hyper-threading'] else row['Num. of Threads'], axis=1)
    df['Adjusted Num. of Threads'] = df['Model'].apply(lambda model: model_threads.get(model, np.nan) if pd.isna(df[df['Model'] == model]['Adjusted Num. of Threads'].values[0]) else df[df['Model'] == model]['Adjusted Num. of Threads'].values[0])

    remaining_nan = df[df['Adjusted Num. of Threads'].isna()]
    if not remaining_nan.empty:
        print("Models with remaining NaN in 'Adjusted Num. of Threads':", remaining_nan['Model'].unique())
    else:
        print("All 'Adjusted Num. of Threads' values filled successfully.")

    df['L2'] = df['L2'].apply(calculate_total_cache)

    if '0' in input_json_path:
        df = df.drop("Adjusted Num. of Threads", axis=1)

    if '1' in input_json_path:
        df['Theoretical Processing Capability'] = round(df['Clock Speed'] * df['Adjusted Num. of Threads'], 2)

    columns_to_transform = ["L3", "Memory"]
    # log transformation
    for column in columns_to_transform:
        df[f"{column}"] = round(np.log1p(df[column]),2)  # log1p(x) is log(x + 1) to avoid log(0)

    df = df.drop(["Performance Score", "Num. of Threads", "Supports Hyper-threading"], axis=1)

    unique_models = df['Model'].unique()
    print(unique_models)

    server_models = df[df['Model'].apply(is_server_model)].drop(columns=['Model'])
    desktop_models = df[df['Model'].apply(is_desktop_model)].drop(columns=['Model'])

    server_output_csv_path = input_json_path.replace(".json", "_server_models.csv")
    desktop_output_csv_path = input_json_path.replace(".json", "_desktop_models.csv")

    server_models.to_csv(server_output_csv_path, index=False)
    desktop_models.to_csv(desktop_output_csv_path, index=False)

    print(f"Server models for {input_json_path} saved to {server_output_csv_path}")
    print(f"Desktop models for {input_json_path} saved to {desktop_output_csv_path}")