import pandas as pd
from itertools import combinations
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.ticker import FuncFormatter

real_data = pd.read_excel('CSG_without_throughput.xlsx', sheet_name='data_with_correlations')
final_centers_df = pd.read_csv('CSG_final_optimized_data_points.csv')

def get_filled_combinations(data):
    combinations_dict = {}
    feature_pairs = list(combinations(data.columns, 2))
    for pair in feature_pairs:
        combinations_dict[pair] = set(tuple(row) for row in data[list(pair)].values)
    return combinations_dict

filled_combinations = get_filled_combinations(real_data)
print("filled combinations for real data: ", filled_combinations)

def evaluate_new_combinations_by_center(center, existing_combinations):
    center_series = pd.Series(center, index=final_centers_df.columns)
    new_filled = False
    new_combinations = []
    for pair in existing_combinations.keys():
        new_combination = tuple(center_series[list(pair)].values)
        if new_combination not in existing_combinations[pair]:
            new_filled = True
            existing_combinations[pair].add(new_combination)
            new_combinations.append((pair, new_combination))
    return new_filled, new_combinations

optimal_centers = set()
new_combinations_filled = []
final_centers_list = [tuple(row) for row in final_centers_df[['cores', 'diskIO', 'Cache', 'MetaData', 'NoofFiles', 'FileSize']].values]

while final_centers_list:
    center = final_centers_list.pop(0)
    new_filled, new_combinations = evaluate_new_combinations_by_center(center, filled_combinations)
    if new_filled:
        optimal_centers.add(center)
        new_combinations_filled.extend([(center, pair, combo) for pair, combo in new_combinations])

optimal_centers_df = pd.DataFrame(list(optimal_centers), columns=final_centers_df.columns)

optimal_centers_df.to_csv('CSG_selected_optimal_centers.csv', index=False)

new_combinations_filled_df = pd.DataFrame(new_combinations_filled, columns=['center', 'feature_pair', 'new_combination'])
new_combinations_filled_df['center'] = new_combinations_filled_df['center'].apply(lambda x: list(x))
new_combinations_filled_df['new_combination'] = new_combinations_filled_df['new_combination'].apply(lambda x: list(x))
new_combinations_filled_df.to_csv('CSG_new_combinations_filled.csv', index=False)

real_data_reset = real_data.reset_index(drop=True)
optimal_centers_reset = optimal_centers_df.reset_index(drop=True)

real_data_reset['source'] = 'Original data'
optimal_centers_reset['source'] = 'Intelligently generated points'

combined_data = pd.concat([real_data_reset, optimal_centers_reset], ignore_index=True)

for col in ['cores', 'diskIO', 'Cache', 'MetaData', 'NoofFiles', 'FileSize']:
    combined_data[col] = pd.to_numeric(combined_data[col], errors='coerce')

combined_data_clean = combined_data.dropna(subset=['cores', 'diskIO', 'Cache', 'MetaData', 'NoofFiles', 'FileSize'])

print(combined_data_clean.dtypes)

sns.set(style="white", palette="bright")
plt.rcParams.update({
    'font.size': 18,           
    'axes.labelsize': 18,      
    'xtick.labelsize': 16,     
    'ytick.labelsize': 16
    })


def integer_formatter(x, pos):
    return f'{int(x)}'

pairplot_real = sns.pairplot(real_data_reset, diag_kind='kde', markers='o',
                             vars=['cores', 'diskIO', 'Cache', 'MetaData', 'NoofFiles', 'FileSize'])
pairplot_real.fig.suptitle('Pair Plot of Original Data', y=1.02, fontsize=24)  # Increased title font size
pairplot_real.fig.set_size_inches(11, 10)

for ax in pairplot_real.axes.flatten():
    ax.xaxis.set_major_formatter(FuncFormatter(integer_formatter))
    ax.yaxis.set_major_formatter(FuncFormatter(integer_formatter))
    ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha='right')

plt.subplots_adjust(left=0.1, right=0.9, top=0.95, bottom=0.1)  # Adjusted layout

plt.show()

pairplot_combined = sns.pairplot(combined_data_clean, hue='source', diag_kind='kde', markers=['o', 's'],
                                 vars=['cores', 'diskIO', 'Cache', 'MetaData', 'NoofFiles', 'FileSize'])
pairplot_combined.fig.set_size_inches(11, 10)

for ax in pairplot_combined.axes.flatten():
    ax.xaxis.set_major_formatter(FuncFormatter(integer_formatter))
    ax.yaxis.set_major_formatter(FuncFormatter(integer_formatter))
    ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha='right')

plt.subplots_adjust(left=0.1, right=0.9, top=0.95, bottom=0.1)  # Adjusted layout
pairplot_combined._legend.remove()

plt.show()

def get_unique_combinations(data):
    combinations_dict = {}
    feature_pairs = list(combinations(data.columns, 2))
    for pair in feature_pairs:
        combinations_dict[pair] = set(tuple(row) for row in data[list(pair)].values)
    return combinations_dict

relevant_columns = ['cores', 'diskIO', 'Cache', 'MetaData', 'NoofFiles', 'FileSize']

original_combinations = get_unique_combinations(real_data[relevant_columns])
filled_combinations = get_unique_combinations(final_centers_df[relevant_columns])
combined_combinations = get_unique_combinations(combined_data_clean[relevant_columns])

def measure_coverage(original, total):
    total_original_combinations = sum(len(combos) for combos in original.values())
    total_combinations = sum(len(combos) for combos in total.values())
    return total_original_combinations / total_combinations

coverage_original = measure_coverage(original_combinations, filled_combinations)
coverage_combined = measure_coverage(combined_combinations, filled_combinations)

def count_unique_combinations(combinations_dict):
    return sum(len(combos) for combos in combinations_dict.values())

original_combinations_count = count_unique_combinations(original_combinations)
combined_combinations_count = count_unique_combinations(combined_combinations)

absolute_increase = combined_combinations_count - original_combinations_count
percentage_increase = (absolute_increase / original_combinations_count) * 100

improvement_results = {
    'Original Combinations Count': original_combinations_count,
    'Combined Combinations Count': combined_combinations_count,
    'Absolute Increase': absolute_increase,
    'Percentage Increase': percentage_increase
}

print("Coverage for Original Data: ", coverage_original)
print("Coverage for Combined Data: ", coverage_combined)
print("Improvement Results: ", improvement_results)