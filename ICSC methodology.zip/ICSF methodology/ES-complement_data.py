import numpy as np
import pandas as pd
from itertools import product


real_data = pd.read_excel('CSG.xlsx', sheet_name='data_with_correlations')

feature_ranges = {
    'cores': sorted(real_data['cores'].unique()),
    'diskIO': sorted(real_data['diskIO'].unique()),
    'Cache': sorted(real_data['Cache'].unique()),
    'MetaData': sorted(real_data['MetaData'].unique()),
    'NoofFiles': sorted(real_data['NoofFiles'].unique()),
    'FileSize': sorted(real_data['FileSize'].unique()),
    'Throughput': sorted(real_data['Throughput'].unique())
}

print("Feature ranges of real data: ")
for feature, values in feature_ranges.items():
    print(f"{feature}: {values}")

all_combinations = list(product(
    feature_ranges['cores'],
    feature_ranges['diskIO'],
    feature_ranges['Cache'],
    feature_ranges['MetaData'],
    feature_ranges['NoofFiles'],
    feature_ranges['FileSize'],
    feature_ranges['Throughput']
))

all_combinations_df = pd.DataFrame(all_combinations, columns=real_data.columns)


all_complement_data = pd.concat([all_combinations_df, real_data, real_data]).drop_duplicates(keep=False)

invalid_complement_data = all_complement_data[
 
    ((all_complement_data['MetaData'] >= 3) & (all_complement_data['Throughput'] <= 3)) |
    ((all_complement_data['diskIO'] >= 3) & (all_complement_data['NoofFiles'] * all_complement_data['FileSize'] <= 5)) |
    ((all_complement_data['Throughput'] >= 7) & (all_complement_data['NoofFiles'] * all_complement_data['FileSize'] <= 5))
]


all_complement_data['Validation'] = np.where(all_complement_data.index.isin(invalid_complement_data.index), 'invalid', 'valid')

valid_count = all_complement_data[all_complement_data['Validation'] == 'valid'].shape[0]
invalid_count = all_complement_data[all_complement_data['Validation'] == 'invalid'].shape[0]
print(f"Number of valid rows: {valid_count}")
print(f"Number of invalid rows: {invalid_count}")

all_complement_data.to_csv('CSG_complement.csv', index=False)

valid_data = all_complement_data[all_complement_data['Validation'] == 'valid']

data = valid_data.drop(columns=['Validation'])

feature_ranges_complement_data = {
    'cores': sorted(real_data['cores'].unique()),
    'diskIO': sorted(real_data['diskIO'].unique()),
    'Cache': sorted(real_data['Cache'].unique()),
    'MetaData': sorted(real_data['MetaData'].unique()),
    'NoofFiles': sorted(real_data['NoofFiles'].unique()),
    'FileSize': sorted(real_data['FileSize'].unique()),
    'Throughput': sorted(real_data['Throughput'].unique())
}


data.to_csv('CSG_valid_complement.csv', index=False)