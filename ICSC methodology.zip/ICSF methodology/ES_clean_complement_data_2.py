import pandas as pd

real_data = pd.read_excel('CSG.xlsx', sheet_name='data_with_correlations')

complemented_data = pd.read_csv('CSG_valid_complement.csv')

feature_ranges = {
    'cores': sorted(real_data['cores'].unique()),
    'diskIO': sorted(real_data['diskIO'].unique()),
    'Cache': sorted(real_data['Cache'].unique()),
    'MetaData': sorted(real_data['MetaData'].unique()),
    'NoofFiles': sorted(real_data['NoofFiles'].unique()),
    'FileSize': sorted(real_data['FileSize'].unique()),
    'Throughput': sorted(real_data['Throughput'].unique())
}

def get_neighbors(point, feature_ranges, columns):
    neighbors = set()
    for i, col in enumerate(columns):
        for delta in [-1, 1]:
            neighbor = point.copy()
            neighbor[i] += delta
            if neighbor[i] in feature_ranges[col]:
                neighbors.add(tuple(neighbor))
    return neighbors


def remove_near_points(real_data, comp_data, feature_ranges):
    real_points = {tuple(row) for row in real_data.values}
    comp_points = {tuple(row) for row in comp_data.values}

    points_to_remove = set()
    for point in real_points:
        points_to_remove.update(get_neighbors(list(point), feature_ranges, real_data.columns))

    initial_count = len(comp_points)

    clean_comp_points = comp_points - points_to_remove

    final_count = len(clean_comp_points)

    removed_count = initial_count - final_count

    clean_complemented_data = pd.DataFrame(list(clean_comp_points), columns=real_data.columns)

    return clean_complemented_data



clean_complemented_data = remove_near_points(real_data, complemented_data, feature_ranges)

clean_complemented_data.to_csv('CSG_clean_complement.csv', index=False)

