import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

data = pd.read_csv('CSG_selected_optimized_data_points.csv')

feature_ranges = {
    'cores': sorted(data['cores'].unique()),
    'diskIO': sorted(data['diskIO'].unique()),
    'Cache': sorted(data['Cache'].unique()),
    'MetaData': sorted(data['MetaData'].unique()),
    'NoofFiles': sorted(data['NoofFiles'].unique()),
    'FileSize': sorted(data['FileSize'].unique()),
    'Throughput': sorted(data['Throughput'].unique())
}

eps = 0.5  # Your epsilon value
scaled_sample_point = 0.5

original_epsilons = {}
for feature in feature_ranges.keys():
    original_range = data[feature].max() - data[feature].min()
    original_epsilon = eps * original_range
    original_epsilons[feature] = original_epsilon
    print(f"Original epsilon for '{feature}': {original_epsilon}")

sample_point = data.iloc[0]

epsilon_ranges = {
    'cores': (sample_point['cores'] - original_epsilons['cores'], sample_point['cores'] + original_epsilons['cores']),
    'diskIO': (sample_point['diskIO'] - original_epsilons['diskIO'], sample_point['diskIO'] + original_epsilons['diskIO']),
    'Cache': (sample_point['Cache'] - original_epsilons['Cache'], sample_point['Cache'] + original_epsilons['Cache']),
    'MetaData': (sample_point['MetaData'] - original_epsilons['MetaData'], sample_point['MetaData'] + original_epsilons['MetaData']),
    'NoofFiles': (sample_point['NoofFiles'] - original_epsilons['NoofFiles'], sample_point['NoofFiles'] + original_epsilons['NoofFiles']),
    'FileSize': (sample_point['FileSize'] - original_epsilons['FileSize'], sample_point['FileSize'] + original_epsilons['FileSize']),
    #'Throughput': (sample_point['Throughput'] - original_epsilons['Throughput'], sample_point['Throughput'] + original_epsilons['Throughput'])
}

for feature, (lower, upper) in epsilon_ranges.items():
    print(f"Epsilon range for {feature}: {lower} to {upper}")

plt.figure(figsize=(12, 8))

for i, (feature, (lower, upper)) in enumerate(epsilon_ranges.items()):
    plt.plot([i, i], [lower, upper], marker='o', label=feature)

plt.xticks(range(len(epsilon_ranges)), epsilon_ranges.keys())
plt.xlabel('Features')
plt.ylabel('Value Range')
plt.title('Epsilon Ranges for Each Feature')
plt.legend()
plt.grid(True)
plt.show()
