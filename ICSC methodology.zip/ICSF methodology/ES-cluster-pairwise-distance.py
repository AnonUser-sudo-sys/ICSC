import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import pairwise_distances

file_path = 'CSG_complemented_data_with_clusters.csv'
data = pd.read_csv(file_path)

cluster_0_data = data[data['cluster'] == 0]

features = cluster_0_data.drop(columns=['cluster'])
scaler = MinMaxScaler()
scaled_features = scaler.fit_transform(features)

distances = pairwise_distances(scaled_features)

distance_df = pd.DataFrame(distances, columns=cluster_0_data.index, index=cluster_0_data.index)

core_points = []
for index, row in distance_df.iterrows():
    if (row <= 0.5).sum() >= 5:
        core_points.append(index)

core_points_df = pd.DataFrame(core_points, columns=["Core Point Index"])

distance_csv_path = 'cluster_0_pairwise_distances.csv'
core_points_csv_path = 'cluster_0_core_points.csv'

distance_df.to_csv(distance_csv_path, index=True)
core_points_df.to_csv(core_points_csv_path, index=False)

print(f'Pairwise distances saved to {distance_csv_path}')
print(f'Core points saved to {core_points_csv_path}')
