import json

with open('geek_data.json', 'r') as f:
    data = json.load(f)

zero_rows = [entry for entry in data if entry[6] == 0]
one_rows = [entry for entry in data if entry[6] == 1]

zero_rows_no_column = [entry[:6] + entry[7:] for entry in zero_rows]
one_rows_no_column = [entry[:6] + entry[7:] for entry in one_rows]

with open('geek_data_1.json', 'w') as one_file:
    json.dump(one_rows_no_column, one_file)

