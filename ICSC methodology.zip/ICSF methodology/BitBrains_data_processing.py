import pandas as pd
import numpy as np

input_file_path = 'combined_BitBrains_data.csv'

columns_to_log_transform = [
    'CPU capacity provisioned [MHZ]', 'Memory capacity provisioned [KB]',
    'Network received throughput [KB/s]', 'Network transmitted throughput [KB/s]',
    'Disk read throughput [KB/s]', 'Disk write throughput [KB/s]'
]

combined_data = pd.read_csv(input_file_path)

combined_data[columns_to_log_transform] = combined_data[columns_to_log_transform].apply(lambda x: np.log1p(x))

output_file_path = 'combined_BitBrains_data_with_log.csv'
combined_data.to_csv(output_file_path, index=False)

print(f"Transformed data saved to {output_file_path}")
